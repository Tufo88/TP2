package simulator.model;

public interface FoodSupplier {
	double get_food(Animal a, double dt);
}
