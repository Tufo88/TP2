package simulator.model;

public enum State {
	NORMAL, MATE, HUNGER, DANGER, DEAD;
}
